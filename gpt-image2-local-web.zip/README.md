# GPT Image 2 Local Web

This folder is a portable local web app for generating and editing images with `gpt-image-2`.

## Start

1. Double-click `scripts/open_app.command`.
2. The browser opens at `http://127.0.0.1:8765`.
3. Type a prompt, optionally upload reference images, then generate.
4. Generated images are saved in `output/imagegen`.

If someone opens `index.html` first, it will point them back to `scripts/open_app.command`.

## Share With Another Mac

Send this whole folder. On the other Mac, edit `config.json` and put a working image API key in `OPENAI_API_KEY`.

If `config.json` is missing, copy `config.example.json` to `config.json` and fill it in.

The startup script uses Python 3 and installs the `openai` Python package if it is missing.

The app uses:

- `OPENAI_BASE_URL`: `https://openox.tech/v1` for your OpenOX route.
- `MODEL`: `gpt-image-2`.
- Local output folder: `output/imagegen`.

## Notes

- Uploading images uses the image edit endpoint.
- No uploaded images means normal image generation.
- The app calls the bundled `scripts/image_gen.py` CLI so it follows the same fallback path as your Codex configuration.
